# function to create list that filters for unique technology/commodity names
# var is MESSAGE variable, e.g. 'ACT'
# col is the to be chosen column, e.g. 'technology'
# group is the prefix or suffix to be filtered for, e.g. '_extr'. If pre- or suffix depends on 'typ' setting. IF set to zero, then no pre-/suffix
# typ is the switch for going for pre- or suffix; prefix for typ = 0
def filter_var(var,col,group,typ):
    mylist = baseline.var(var)[col].unique().tolist()
    if group == 0 and typ == 0:
        newlist = mylist
    elif typ == 0:
        r = re.compile("{}.*".format(group))
        newlist = list(filter(r.match, mylist))
    else:
        r = re.compile(".*{}".format(group))
        newlist = list(filter(r.match, mylist))
    return newlist

# function to plot 'lvl' and 'mrg' of the selected MESSAGE variable, grouped by year (of activity/demand/...); vintage years are grouped together
# scenario is the chosen scenario
# var is MESSAGE variable, e.g. 'ACT'
# col is the to be chosen column, e.g. 'technology'
# ls is a list of unique technology/commodity names, resulting from the 'filter_var' function
def plot_var(scenario,var,col,ls):
    df = scenario.var(var)
    if var == 'ACT' or var == 'CAP':
        year = 'year_act'
    elif var == 'CAP_NEW':
        year == 'year_vtg'
    else:
        year = 'year'
    fig, (ax1,ax2) = plt.subplots(1,2)
    if col == 0 and ls == 0:
        if var == 'EMISS':#emissions of ZA and the world are the same, therfore this work-around works
            df.groupby([year, 'emission']).sum()['lvl'].unstack().plot.bar(ax=ax1, figsize=(15, 5), legend=False)
            df.groupby([year, 'emission']).sum()['mrg'].unstack().plot.bar(ax=ax2).legend(loc='best')
        else:
            df.groupby([year, 'node']).sum()['lvl'].unstack().plot.bar(ax=ax1, figsize=(15, 5), legend=False)
            df.groupby([year, 'node']).sum()['mrg'].unstack().plot.bar(ax=ax2).legend(loc='best')
    else:
        df = df.loc[df[col].isin(ls)]
        df.groupby([year, col]).sum()['lvl'].unstack().plot.bar(ax=ax1, figsize=(15, 5), legend=False)
        df.groupby([year, col]).sum()['mrg'].unstack().plot.bar(ax=ax2).legend(loc='best')
    plt.subplots_adjust(wspace=0.50)
    ax1.set_title('lvl of selected variable',size=10)
    ax2.set_title('mrg of selected variable',size=10)